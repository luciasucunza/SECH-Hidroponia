/* Includes ------------------------------------------------------------------*/
#include "config_flash.h"

/* Initial flash values ------------------------------------------------------*/
__root const uint32_t config_flash[] @ FLASH_PAGE1_ADDRESS =
{
15,
35,
60,
95,
0x000ADDED // binary file needs to be multiple of 4x32bits words for DFU generation to work
};


/* Flash min. & max. values --------------------------------------------------*/
__root const uint32_t config_min[] =
{
0,
0,
0,
0,
0    // Contrast min
};
__root const uint32_t config_max[] =
{
50,
50,
100,
100,
0x001F    // Contrast max
};

/* Private Data --------------------------------------------------------------*/
uint32_t flash_copy[FLASH_INFO_SIZE];
uint8_t Flash_State = 0;
uint32_t Flash_Timer;
