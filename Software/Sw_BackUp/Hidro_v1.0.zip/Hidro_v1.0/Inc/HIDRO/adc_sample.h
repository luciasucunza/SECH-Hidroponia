#ifndef __ADC_SAMPLE_H
#define __ADC_SAMPLE_H

/* Includes ------------------------------------------------------------------*/
#include "adc.h"
#include "common.h"
#include "config_flash.h"
#include "main.h"      //Solo por Error_Handler

/* Function ------------------------------------------------------------------*/
void adc_task (void);
//void adc_1s_tick (void);
void adc_new_sample(uint8_t);
bool adc_done(uint8_t);
void adc_select_channel(uint32_t);
bool start_sampling(uint32_t);
uint16_t finish_sampling(void);
float sample_math(uint16_t, uint32_t);

/* Exported Variables --------------------------------------------------------*/
extern volatile tREG08 Flags_ADC;
extern float ph;
extern float ec;

/* Defines -------------------------------------------------------------------*/
#define Flag_ADC_Cmd_Ph	             Flags_ADC.Bit._0
#define Flag_ADC_Cmd_Ec              Flags_ADC.Bit._1
#define ADC_CMD_PH                    0x01        // Mascaras para Flags
#define ADC_CMD_EC                    0x02
#define ADC_CMD_MASK                  0x03
#define Flag_ADC_Error_Ph	           Flags_ADC.Bit._2
#define Flag_ADC_Error_Ec            Flags_ADC.Bit._3
#define Flag_ADC_Electrode_Ready     Flags_ADC.Bit._4

#define CH_PH             ADC_CHANNEL_4
#define CH_EC             ADC_CHANNEL_2

#define LOG2_NUM_SAMP			3                         // Pasar a 5 para EC
#define NUM_SAMP				  (1<<LOG2_NUM_SAMP)//+2      // SE SUMAN 2 para eliminar 
                                                    // los extremos y promediar

#define ADC_RES           4095
#define REF_VOLTAGE       3.38  //V   Valor preciso:  3.3v*Vref_cal/Vref_data
                                //              -Vref_cal  = Valor en memoria
                                //              -Vref_data = Obtener por ADC_17

/*States ---------------------------------------------------------------------*/
enum{
  ADC_WAITING,
  ADC_SAMPLING_PH,
  ADC_SAMPLING_EC
};

#endif  /* __ADC_SAMPLE_H  */