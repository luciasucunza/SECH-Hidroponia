#ifndef VERSION_H
#define VERSION_H

/* The major version */
#define MAJOR_VERSION       0

/* The minor version */
#define MINOR_VERSION       1

/* The revision version */
#define REVISION_VERSION    0

#endif /* VERSION_H */
